<?php
if (!defined('puyuetian'))
	exit('403');

$HTMLCODE .= template("{$tpath}environment.hst", TRUE);
