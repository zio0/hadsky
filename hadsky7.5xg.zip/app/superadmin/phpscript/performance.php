<?php
if (!defined('puyuetian'))
	exit('403');

$contenthtml = template('superadmin:performance-' . $_G['GET']['T'], TRUE);
